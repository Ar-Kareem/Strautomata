## Licensing
Epoch AI's data is free to use, distribute, and reproduce provided the source and authors are credited under the [Creative Commons Attribution license](https://creativecommons.org/licenses/by/4.0/).

### Citation
```
Epoch AI, ‘Capabilities & Benchmarking’. Published online at epoch.ai. Retrieved from ‘https://epoch.ai/benchmarks’ [online resource].
```

### BibTeX Citation
```
@misc{EpochLLMBenchmarkingHub2024,
  title = {{Capabilities & Benchmarking}},
  author = {{Epoch AI}},
  year = {2026},
  month = {09},
  url = {https://epoch.ai/benchmarks}
}
```
